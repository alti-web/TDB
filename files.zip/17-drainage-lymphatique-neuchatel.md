---
title: "Drainage Lymphatique à Neuchâtel | ASCA/RME — Olistik"
description: "Drainage lymphatique à Neuchâtel : Renata França, Vodder et soins spécialisés. Centre agréé ASCA/RME à Peseux pour drainages manuels professionnels."
slug: drainage-lymphatique-neuchatel
canonical: https://olistik.ch/drainage-lymphatique-neuchatel
h1: "Drainage lymphatique à Neuchâtel : relancer, alléger, rééquilibrer"
silo: 3 — Drainage Lymphatique & Silhouette
type: pilier
---

# Drainage lymphatique à Neuchâtel : relancer, alléger, rééquilibrer

## Le drainage lymphatique : bien plus qu'un simple massage

Le drainage lymphatique est une technique manuelle spécialisée qui stimule la circulation de la lymphe dans l'organisme. La lymphe transporte les déchets métaboliques, les toxines et les excès d'eau hors des tissus. Lorsque le système lymphatique est ralenti, les conséquences apparaissent : jambes lourdes, gonflements, rétention d'eau, sensation de lourdeur générale et fatigue.

## Les drainages proposés chez Olistik

Chez Olistik à Peseux (Neuchâtel), nous proposons plusieurs approches complémentaires :

### Drainage Renata França
Technique brésilienne dynamique et tonique. Effet sculptant et dégonflant immédiat. Idéal pour la rétention d'eau, les jambes lourdes et l'affinement de la silhouette.

### Drainage Vodder
Méthode de référence en drainage lymphatique manuel. Mouvements lents, doux et extrêmement précis. Indiqué pour les problématiques chroniques, les œdèmes, le lipoedème et les patients sensibles.

### Drainage pré et post opératoire
Accompagnement avant et après chirurgie (esthétique, orthopédique, dentaire). Préparation des tissus et accélération de la récupération.

## Indications principales

- Jambes lourdes et rétention d'eau
- Gonflements et œdèmes
- Lipoedème
- Préparation et récupération post-chirurgicale
- Détoxification saisonnière
- Accompagnement de la grossesse
- Cellulite avec composante circulatoire

## Tarifs et remboursement

Séances de 60 minutes à CHF 130.-. Praticiens agréés ASCA, RME et O'LRNIS. Remboursement possible par votre complémentaire.

---

**Liens internes :**
- [Drainage Renata França à Neuchâtel](/drainage-renata-franca-neuchatel)
- [Drainage Vodder à Neuchâtel](/drainage-vodder-neuchatel)
- [Drainage jambes lourdes à Neuchâtel](/drainage-jambes-lourdes-retention-eau-neuchatel)
- [Drainage post-opératoire à Neuchâtel](/drainage-post-operatoire-neuchatel)
- [Drainage pré-opératoire à Neuchâtel](/drainage-pre-operatoire-chirurgie-esthetique-neuchatel)
- [Drainage grossesse et prénatal à Neuchâtel](/drainage-grossesse-prenatal-neuchatel)
- [Drainage détox changement de saison à Neuchâtel](/drainage-detox-changement-saison-neuchatel)
- [Traitement anticellulite à Neuchâtel](/traitement-anticellulite-neuchatel)
- [Soins minceur technologies à Neuchâtel](/soins-minceur-technologies-neuchatel)
