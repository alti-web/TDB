# Schéma du Cocon Sémantique SEO — Olistik.ch

## Architecture globale : 52 pages réparties en 8 thématiques (silos)

---

## SILO 1 — Massages Thérapeutiques & Bien-être (10 pages)

```
PAGE PILIER : massage-therapeutique-neuchatel.md
│
├── massage-dos-neuchatel.md
├── massage-cervicales-nuque-neuchatel.md
├── massage-tensions-musculaires-neuchatel.md
├── massage-sciatique-lombalgie-neuchatel.md
├── massage-migraine-maux-de-tete-neuchatel.md
├── massage-relaxant-anti-stress-neuchatel.md
├── massage-pierres-chaudes-bienfaits-neuchatel.md
├── massage-insomnie-troubles-sommeil-neuchatel.md
└── massage-asca-rme-remboursement-neuchatel.md
```

**Maillage interne :**
- Chaque page enfant → lien vers le pilier + 2 pages sœurs
- Le pilier → lien vers chaque enfant + lien vers Silo 2 (Sportif) et Silo 3 (Drainage)

---

## SILO 2 — Massage Sportif & Récupération (6 pages)

```
PAGE PILIER : massage-sportif-neuchatel.md
│
├── massage-recuperation-sportive-neuchatel.md
├── massage-avant-apres-competition-neuchatel.md
├── massage-tendinite-contracture-neuchatel.md
├── massage-sportif-course-a-pied-neuchatel.md
└── massage-sportif-crossfit-musculation-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + 1 page sœur + lien vers Silo 1 (Thérapeutique)
- Le pilier → chaque enfant + lien vers Silo 1

---

## SILO 3 — Drainage Lymphatique & Silhouette (8 pages)

```
PAGE PILIER : drainage-lymphatique-neuchatel.md
│
├── drainage-renata-franca-neuchatel.md
├── drainage-vodder-neuchatel.md
├── drainage-jambes-lourdes-retention-eau-neuchatel.md
├── drainage-post-operatoire-neuchatel.md
├── drainage-pre-operatoire-chirurgie-esthetique-neuchatel.md
├── drainage-grossesse-prenatal-neuchatel.md
└── drainage-detox-changement-saison-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + 2 pages sœurs
- Le pilier → chaque enfant + lien vers Silo 4 (Anticellulite) et Silo 5 (Minceur)

---

## SILO 4 — Anticellulite & Remodelage (6 pages)

```
PAGE PILIER : traitement-anticellulite-neuchatel.md
│
├── massage-anticellulite-manuel-neuchatel.md
├── cellulite-cuisses-fesses-solutions-neuchatel.md
├── cellulite-fibreuse-adipeuse-aqueuse-neuchatel.md
├── maderotherapie-anticellulite-neuchatel.md
└── endospheres-anticellulite-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + 1 page sœur + lien vers Silo 3 (Drainage)
- Le pilier → chaque enfant + lien vers Silo 5 (Minceur)

---

## SILO 5 — Soins Minceur & Technologies Corps (8 pages)

```
PAGE PILIER : soins-minceur-technologies-neuchatel.md
│
├── cryolipolyse-neuchatel.md
├── emsculpt-bodysculpt-neuchatel.md
├── lipocavitation-neuchatel.md
├── radiofrequence-corps-neuchatel.md
├── cellu-m6-lpg-endermologie-neuchatel.md
├── sauna-japonais-dome-infrarouge-neuchatel.md
└── perdre-ventre-graisse-abdominale-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + 2 pages sœurs
- Le pilier → chaque enfant + lien vers Silo 4 et Silo 6 (Lipoedème)

---

## SILO 6 — Lipoedème (4 pages)

```
PAGE PILIER : lipoedeme-traitement-neuchatel.md
│
├── lipoedeme-symptomes-diagnostic-neuchatel.md
├── lipoedeme-drainage-lymphatique-neuchatel.md
└── lipoedeme-protocole-prise-en-charge-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + pages sœurs
- Le pilier → chaque enfant + lien vers Silo 3 (Drainage) et Silo 5 (Minceur)

---

## SILO 7 — Soins Visage Anti-Âge & Kobido (6 pages)

```
PAGE PILIER : soins-visage-anti-age-neuchatel.md
│
├── kobido-lifting-naturel-visage-neuchatel.md
├── radiofrequence-visage-rides-neuchatel.md
├── endospheres-visage-eclat-neuchatel.md
├── soin-lift-progressif-visage-neuchatel.md
└── rides-relachement-cutane-solutions-naturelles-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + 1 page sœur
- Le pilier → chaque enfant + lien vers Silo 1 (Relaxant/bien-être)

---

## SILO 8 — Épilation Laser & Esthétique (4 pages)

```
PAGE PILIER : epilation-laser-definitive-neuchatel.md
│
├── epilation-laser-maillot-aisselles-neuchatel.md
├── epilation-laser-visage-duvet-neuchatel.md
└── epilation-laser-jambes-corps-entier-neuchatel.md
```

**Maillage interne :**
- Chaque enfant → pilier + pages sœurs
- Le pilier → chaque enfant

---

## Schéma visuel de maillage inter-silos

```
                    ┌──────────────────────────┐
                    │   PAGE D'ACCUEIL          │
                    │   olistik.ch              │
                    └─────────┬────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
    ┌─────▼─────┐     ┌──────▼──────┐    ┌───────▼──────┐
    │ SILO 1    │     │  SILO 2     │    │   SILO 3     │
    │ Massage   │◄───►│  Sportif    │    │  Drainage    │
    │ Thérap.   │     │  Récup.     │    │  Lymphatique │
    │ (10 p.)   │     │  (6 p.)     │    │  (8 p.)      │
    └─────┬─────┘     └─────────────┘    └──┬──────┬────┘
          │                                 │      │
          │           ┌─────────────────────┘      │
          │           │                            │
    ┌─────▼─────┐  ┌──▼──────────┐    ┌───────────▼──┐
    │ SILO 7    │  │  SILO 4     │    │   SILO 5      │
    │ Visage    │  │  Anticell.  │◄──►│  Minceur      │
    │ Anti-Âge  │  │  Remodelage │    │  Technologies │
    │ (6 p.)    │  │  (6 p.)     │    │  (8 p.)       │
    └───────────┘  └─────────────┘    └──────┬────────┘
                                             │
                   ┌─────────────┐    ┌──────▼────────┐
                   │  SILO 8     │    │   SILO 6      │
                   │  Épilation  │    │  Lipoedème    │
                   │  Laser      │    │  (4 p.)       │
                   │  (4 p.)     │    └───────────────┘
                   └─────────────┘

TOTAL : 8 pages piliers + 44 pages enfants = 52 pages
```

---

## Récapitulatif des 52 fichiers

| #  | Silo | Fichier | Type |
|----|------|---------|------|
| 1  | 1 | `massage-therapeutique-neuchatel.md` | Pilier |
| 2  | 1 | `massage-dos-neuchatel.md` | Enfant |
| 3  | 1 | `massage-cervicales-nuque-neuchatel.md` | Enfant |
| 4  | 1 | `massage-tensions-musculaires-neuchatel.md` | Enfant |
| 5  | 1 | `massage-sciatique-lombalgie-neuchatel.md` | Enfant |
| 6  | 1 | `massage-migraine-maux-de-tete-neuchatel.md` | Enfant |
| 7  | 1 | `massage-relaxant-anti-stress-neuchatel.md` | Enfant |
| 8  | 1 | `massage-pierres-chaudes-bienfaits-neuchatel.md` | Enfant |
| 9  | 1 | `massage-insomnie-troubles-sommeil-neuchatel.md` | Enfant |
| 10 | 1 | `massage-asca-rme-remboursement-neuchatel.md` | Enfant |
| 11 | 2 | `massage-sportif-neuchatel.md` | Pilier |
| 12 | 2 | `massage-recuperation-sportive-neuchatel.md` | Enfant |
| 13 | 2 | `massage-avant-apres-competition-neuchatel.md` | Enfant |
| 14 | 2 | `massage-tendinite-contracture-neuchatel.md` | Enfant |
| 15 | 2 | `massage-sportif-course-a-pied-neuchatel.md` | Enfant |
| 16 | 2 | `massage-sportif-crossfit-musculation-neuchatel.md` | Enfant |
| 17 | 3 | `drainage-lymphatique-neuchatel.md` | Pilier |
| 18 | 3 | `drainage-renata-franca-neuchatel.md` | Enfant |
| 19 | 3 | `drainage-vodder-neuchatel.md` | Enfant |
| 20 | 3 | `drainage-jambes-lourdes-retention-eau-neuchatel.md` | Enfant |
| 21 | 3 | `drainage-post-operatoire-neuchatel.md` | Enfant |
| 22 | 3 | `drainage-pre-operatoire-chirurgie-esthetique-neuchatel.md` | Enfant |
| 23 | 3 | `drainage-grossesse-prenatal-neuchatel.md` | Enfant |
| 24 | 3 | `drainage-detox-changement-saison-neuchatel.md` | Enfant |
| 25 | 4 | `traitement-anticellulite-neuchatel.md` | Pilier |
| 26 | 4 | `massage-anticellulite-manuel-neuchatel.md` | Enfant |
| 27 | 4 | `cellulite-cuisses-fesses-solutions-neuchatel.md` | Enfant |
| 28 | 4 | `cellulite-fibreuse-adipeuse-aqueuse-neuchatel.md` | Enfant |
| 29 | 4 | `maderotherapie-anticellulite-neuchatel.md` | Enfant |
| 30 | 4 | `endospheres-anticellulite-neuchatel.md` | Enfant |
| 31 | 5 | `soins-minceur-technologies-neuchatel.md` | Pilier |
| 32 | 5 | `cryolipolyse-neuchatel.md` | Enfant |
| 33 | 5 | `emsculpt-bodysculpt-neuchatel.md` | Enfant |
| 34 | 5 | `lipocavitation-neuchatel.md` | Enfant |
| 35 | 5 | `radiofrequence-corps-neuchatel.md` | Enfant |
| 36 | 5 | `cellu-m6-lpg-endermologie-neuchatel.md` | Enfant |
| 37 | 5 | `sauna-japonais-dome-infrarouge-neuchatel.md` | Enfant |
| 38 | 5 | `perdre-ventre-graisse-abdominale-neuchatel.md` | Enfant |
| 39 | 6 | `lipoedeme-traitement-neuchatel.md` | Pilier |
| 40 | 6 | `lipoedeme-symptomes-diagnostic-neuchatel.md` | Enfant |
| 41 | 6 | `lipoedeme-drainage-lymphatique-neuchatel.md` | Enfant |
| 42 | 6 | `lipoedeme-protocole-prise-en-charge-neuchatel.md` | Enfant |
| 43 | 7 | `soins-visage-anti-age-neuchatel.md` | Pilier |
| 44 | 7 | `kobido-lifting-naturel-visage-neuchatel.md` | Enfant |
| 45 | 7 | `radiofrequence-visage-rides-neuchatel.md` | Enfant |
| 46 | 7 | `endospheres-visage-eclat-neuchatel.md` | Enfant |
| 47 | 7 | `soin-lift-progressif-visage-neuchatel.md` | Enfant |
| 48 | 7 | `rides-relachement-cutane-solutions-naturelles-neuchatel.md` | Enfant |
| 49 | 8 | `epilation-laser-definitive-neuchatel.md` | Pilier |
| 50 | 8 | `epilation-laser-maillot-aisselles-neuchatel.md` | Enfant |
| 51 | 8 | `epilation-laser-visage-duvet-neuchatel.md` | Enfant |
| 52 | 8 | `epilation-laser-jambes-corps-entier-neuchatel.md` | Enfant |
