# Architecture du Cocon Sémantique – ad-coaching.fr
## 27 Pages SEO organisées en clusters thématiques

---

## 🏠 PAGE PILIER PRINCIPALE

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 01 | `01-coach-sportif-cannes.md` | coach sportif cannes | /coach-sportif-cannes/ |

---

## 🏋️ CLUSTER SERVICES / FORMATS (5 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 02 | `02-coach-sportif-domicile-cannes.md` | coach sportif à domicile cannes | /coach-sportif-domicile-cannes/ |
| 03 | `03-coach-sportif-exterieur-cannes.md` | coach sportif extérieur cannes | /coach-sportif-exterieur-cannes/ |
| 04 | `04-coaching-sportif-studio-cannes.md` | coaching sportif studio cannes | /coaching-sportif-studio-cannes/ |
| 05 | `05-nutrition-reequilibrage-alimentaire-cannes.md` | rééquilibrage alimentaire cannes | /nutrition-reequilibrage-alimentaire-cannes/ |
| 06 | `06-coaching-mental-pnl-cannes.md` | coaching mental PNL cannes | /coaching-mental-pnl-cannes/ |

---

## 🎯 CLUSTER OBJECTIFS / PUBLICS (5 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 07 | `07-coach-sportif-perte-de-poids-cannes.md` | coach sportif perte de poids cannes | /coach-sportif-perte-de-poids-cannes/ |
| 08 | `08-renforcement-musculaire-cannes.md` | renforcement musculaire cannes | /renforcement-musculaire-cannes/ |
| 09 | `09-remise-en-forme-cannes.md` | remise en forme cannes | /remise-en-forme-cannes/ |
| 10 | `10-coach-sportif-senior-cannes.md` | coach sportif senior cannes | /coach-sportif-senior-cannes/ |
| 11 | `11-coach-sportif-femme-cannes.md` | coach sportif femme cannes | /coach-sportif-femme-cannes/ |

---

## 💰 CLUSTER COMMERCIAL (2 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 12 | `12-tarif-coach-sportif-cannes.md` | tarif coach sportif cannes | /tarif-coach-sportif-cannes/ |
| 23 | `23-credit-impot-coaching-sportif-domicile.md` | crédit impôt coaching sportif domicile | /credit-impot-coaching-sportif-domicile/ |

---

## 📍 CLUSTER GÉOGRAPHIQUE (6 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 13 | `13-coach-sportif-le-cannet.md` | coach sportif le cannet | /coach-sportif-le-cannet/ |
| 14 | `14-coach-sportif-mougins.md` | coach sportif mougins | /coach-sportif-mougins/ |
| 15 | `15-coach-sportif-antibes.md` | coach sportif antibes | /coach-sportif-antibes/ |
| 16 | `16-coach-sportif-mandelieu.md` | coach sportif mandelieu | /coach-sportif-mandelieu/ |
| 17 | `17-coach-sportif-grasse.md` | coach sportif grasse | /coach-sportif-grasse/ |
| 24 | `24-coach-sportif-cote-azur.md` | coach sportif côte d'azur | /coach-sportif-cote-azur/ |

---

## 📚 CLUSTER ÉDITORIAL / INFORMATIONNEL (5 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 18 | `18-comment-choisir-coach-sportif-cannes.md` | comment choisir coach sportif cannes | /comment-choisir-coach-sportif-cannes/ |
| 19 | `19-sport-gestion-stress-cannes.md` | sport gestion stress cannes | /sport-gestion-stress-cannes/ |
| 20 | `20-sport-apres-40-ans-cannes.md` | sport après 40 ans cannes | /sport-apres-40-ans-cannes/ |
| 21 | `21-coach-sportif-dirigeant-entrepreneur-cannes.md` | coach sportif dirigeant cannes | /coach-sportif-dirigeant-entrepreneur-cannes/ |
| 22 | `22-coach-personnel-vs-salle-de-sport.md` | coach personnel vs salle de sport | /coach-personnel-vs-salle-de-sport/ |

---

## 🌟 CLUSTER CONFIANCE / E-REPUTATION (2 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 25 | `25-avis-coach-sportif-cannes.md` | avis coach sportif cannes | /avis-coach-sportif-cannes/ |
| 26 | `26-alexandre-dio-coach-sportif-cannes.md` | alexandre dio coach sportif cannes | /alexandre-dio-coach-sportif-cannes/ |

---

## 🏖️ CLUSTER SAISONNIER (1 page)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 27 | `27-preparation-physique-ete-cannes.md` | préparation physique été cannes | /preparation-physique-ete-cannes/ |

---

## 🔗 SCHÉMA DE MAILLAGE INTERNE

```
                         [01 - Coach Sportif Cannes]
                        /           |              \
                       /            |               \
     [CLUSTER SERVICES]    [CLUSTER OBJECTIFS]    [CLUSTER GÉO]
      02,03,04,05,06        07,08,09,10,11       13,14,15,16,17,24
            ↕                     ↕                     ↕
     [CLUSTER COMMERCIAL]  [CLUSTER ÉDITORIAL]   [CLUSTER CONFIANCE]
          12,23             18,19,20,21,22           25,26
                                  ↕
                          [CLUSTER SAISONNIER]
                               27
```

### Règles de maillage :
1. **Chaque page enfant** renvoie vers sa page pilier de cluster ET vers la page pilier principale (01)
2. **Les pages du même cluster** sont liées entre elles (maillage horizontal)
3. **Les clusters se lient entre eux** via des liens contextuels (ex : page tarif → pages services ET objectifs)
4. **Toutes les pages** renvoient vers la page contact (/contact/)
5. **Les pages géographiques** renvoient vers les pages services correspondantes (domicile, extérieur)

---

## 📊 DONNÉES CLÉS

- **27 pages** au total
- **27 mots-clés principaux** distincts
- **~120 mots-clés secondaires** couverts
- **7 clusters thématiques** interconnectés
- **Toutes les pages** rédigées en français, optimisées SEO avec meta title, meta description, URL, H1, H2, H3
- **Maillage interne** défini pour chaque page
- **CTA** vers la page contact sur chaque page
- **Points forts SEO exploités** : crédit d'impôt 50%, SAP, AICI, diplômé d'État, +100 avis 5 étoiles, +10 ans d'expérience, approche 360°

---

## 🗓️ RECOMMANDATIONS DE PUBLICATION

**Phase 1 (semaines 1-2)** : Pages pilier + cluster services (01 à 06)
**Phase 2 (semaines 3-4)** : Cluster objectifs/publics (07 à 11)
**Phase 3 (semaines 5-6)** : Cluster géographique (13 à 17, 24)
**Phase 4 (semaines 7-8)** : Cluster commercial + éditorial (12, 18 à 23)
**Phase 5 (semaines 9-10)** : Cluster confiance + saisonnier (25 à 27)
