# Tarif Coach Sportif à Cannes : Quel Budget Prévoir ?

**Meta Title :** Tarif Coach Sportif Cannes | Prix, Formules & Crédit d'Impôt 50%
**Meta Description :** Tarifs coach sportif à Cannes. Formules dès 192€/mois. Crédit d'impôt 50% sur séances à domicile. Séance découverte offerte sans engagement.
**URL suggérée :** /tarif-coach-sportif-cannes/
**Mot-clé principal :** tarif coach sportif cannes
**Mots-clés secondaires :** prix coach sportif cannes, combien coûte un coach sportif, tarif personal trainer cannes

---

## Combien coûte un coach sportif à Cannes ?

Le tarif d'un coach sportif professionnel varie selon le format, la durée du programme et la fréquence. Alexandre Dio propose des formules structurées intégrant l'approche globale 360° : préparation physique, suivi nutritionnel et accompagnement mental.

## Les formules

**Santé & Vitalité Senior** (24 semaines) : séances douces, équilibre, posture, suivi personnalisé. À partir de **400 €/mois**.

**Reprise du Sport** (12 semaines) : séances progressives, bilan forme, conseils nutrition. À partir de **192 €/mois**.

**Silhouette & Bien-être** (12 semaines) : spécial femmes, tonification, rééquilibrage. À partir de **384 €/mois**.

## Le crédit d'impôt de 50 %

Les séances à domicile sont éligibles au Service à la Personne. Une formule à 400 €/mois revient à **200 €/mois** après crédit d'impôt. Alexandre est déclaré et agréé SAP.

## Ce qui est inclus

Les séances avec matériel fourni, le plan nutritionnel personnalisé, le suivi hebdomadaire, le coaching mental, le bilan santé initial et la disponibilité entre les séances.

## Investir dans sa santé

80 % des abonnés en salle abandonnent dans les 3 premiers mois. Un coach vous garantit régularité, progression et résultats. C'est un investissement dans votre santé et votre qualité de vie.

→ [Réserver ma séance découverte offerte](/contact/)

---

**Maillage interne suggéré :**
- [Coach sportif Cannes](/coach-sportif-cannes/)
- [Coach sportif à domicile Cannes](/coach-sportif-domicile-cannes/)
- [Avis coach sportif Cannes](/avis-coach-sportif-cannes/)
- [Coach sportif senior Cannes](/coach-sportif-senior-cannes/)
