# Architecture du Cocon Sémantique – mentaliste.paris
## 27 Pages SEO organisées en clusters thématiques

---

## 🏠 PAGE PILIER PRINCIPALE

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 01 | `01-mentaliste-paris.md` | mentaliste paris | /mentaliste-paris/ |

---

## 🏢 CLUSTER ENTREPRISE (6 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 02 | `02-mentaliste-soiree-entreprise-paris.md` | mentaliste soirée entreprise paris | /mentaliste-soiree-entreprise-paris/ |
| 03 | `03-mentaliste-seminaire-entreprise.md` | mentaliste séminaire entreprise | /mentaliste-seminaire-entreprise/ |
| 04 | `04-mentaliste-team-building-paris.md` | mentaliste team building paris | /mentaliste-team-building-paris/ |
| 05 | `05-mentaliste-soiree-gala-paris.md` | mentaliste soirée de gala paris | /mentaliste-soiree-gala-paris/ |
| 06 | `06-mentaliste-lancement-produit.md` | mentaliste lancement de produit | /mentaliste-lancement-produit/ |
| 07 | `07-mentaliste-soiree-noel-entreprise.md` | mentaliste soirée noël entreprise | /mentaliste-soiree-noel-entreprise/ |

---

## 🎉 CLUSTER PARTICULIERS (4 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 08 | `08-mentaliste-mariage-anniversaire-paris.md` | mentaliste mariage anniversaire paris | /mentaliste-mariage-anniversaire-paris/ |
| 09 | `09-mentaliste-mariage-paris.md` | mentaliste mariage paris | /mentaliste-mariage-paris/ |
| 10 | `10-mentaliste-anniversaire-paris.md` | mentaliste anniversaire paris | /mentaliste-anniversaire-paris/ |
| 21 | `21-mentaliste-soiree-privee-paris.md` | mentaliste soirée privée paris | /mentaliste-soiree-privee-paris/ |

---

## 🎭 CLUSTER FORMATS / PRESTATIONS (3 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 11 | `11-spectacle-mentalisme-scene-paris.md` | spectacle mentalisme scène paris | /spectacle-mentalisme-scene-paris/ |
| 12 | `12-close-up-mentalisme-cocktail-paris.md` | close-up mentalisme cocktail paris | /close-up-mentalisme-cocktail-paris/ |
| 13 | `13-salon-des-mysteres-mentalisme.md` | salon des mystères mentalisme | /salon-des-mysteres-mentalisme/ |

---

## 💰 CLUSTER COMMERCIAL (2 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 14 | `14-tarif-mentaliste-paris.md` | tarif mentaliste paris | /tarif-mentaliste-paris/ |
| 18 | `18-comment-choisir-mentaliste.md` | comment choisir un mentaliste | /comment-choisir-mentaliste/ |

---

## 📍 CLUSTER GÉOGRAPHIQUE (2 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 15 | `15-mentaliste-ile-de-france.md` | mentaliste île-de-france | /mentaliste-ile-de-france/ |
| 16 | `16-mentaliste-yvelines.md` | mentaliste yvelines | /mentaliste-yvelines/ |

---

## 📚 CLUSTER ÉDITORIAL / INFORMATIONNEL (5 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 17 | `17-difference-mentaliste-magicien.md` | différence mentaliste magicien | /difference-mentaliste-magicien/ |
| 19 | `19-quest-ce-que-le-mentalisme.md` | qu'est-ce que le mentalisme | /quest-ce-que-le-mentalisme/ |
| 22 | `22-animation-cocktail-entreprise-paris.md` | animation cocktail entreprise paris | /animation-cocktail-entreprise-paris/ |
| 23 | `23-idees-animation-soiree-entreprise-paris.md` | idée animation soirée entreprise paris | /idees-animation-soiree-entreprise-paris/ |
| 25 | `25-mentaliste-bar-mitsvah-communion-paris.md` | mentaliste bar-mitsvah communion paris | /mentaliste-bar-mitsvah-communion-paris/ |

---

## 🌟 CLUSTER CONFIANCE / E-REPUTATION (2 pages)

| # | Fichier | Mot-clé principal | URL suggérée |
|---|---------|-------------------|--------------|
| 24 | `24-mentaliste-comite-entreprise-cse.md` | mentaliste comité d'entreprise | /mentaliste-comite-entreprise-cse/ |
| 26 | `26-avis-mentaliste-paris.md` | avis mentaliste paris | /avis-mentaliste-paris/ |
| 27 | `27-jean-baptiste-clement-mentaliste-paris.md` | jean-baptiste clément mentaliste paris | /jean-baptiste-clement-mentaliste-paris/ |

---

## 🔗 SCHÉMA DE MAILLAGE INTERNE

```
                        [01 - Mentaliste Paris]
                       /          |            \
                      /           |             \
    [CLUSTER ENTREPRISE]   [CLUSTER PARTICULIERS]   [CLUSTER FORMATS]
     02 → 03,04,05,06,07    08 → 09,10,21          11,12,13
           ↕                      ↕                    ↕
    [CLUSTER COMMERCIAL]   [CLUSTER ÉDITORIAL]    [CLUSTER GÉO]
        14,18               17,19,22,23,25          15,16
                                  ↕
                        [CLUSTER CONFIANCE]
                          24,26,27
```

### Règles de maillage :
1. **Chaque page enfant** renvoie vers sa page pilier de cluster ET vers la page pilier principale (01)
2. **Les pages du même cluster** sont liées entre elles (maillage horizontal)
3. **Les clusters se lient entre eux** via des liens contextuels (ex : page tarif → pages entreprise ET particuliers)
4. **Toutes les pages** renvoient vers la page contact/devis

---

## 📊 DONNÉES CLÉS

- **27 pages** au total
- **27 mots-clés principaux** distincts
- **~100 mots-clés secondaires** couverts
- **6 clusters thématiques** interconnectés
- **Toutes les pages** rédigées en français, optimisées SEO avec meta title, meta description, URL, H1, H2, H3
- **Maillage interne** défini pour chaque page
- **CTA** vers la page contact sur chaque page
